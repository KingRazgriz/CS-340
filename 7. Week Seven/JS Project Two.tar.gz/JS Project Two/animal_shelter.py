from pymongo import MongoClient
from pymongo.errors import PyMongoError
from typing import Dict, List, Optional
import urllib.parse

class AnimalShelter:
    """A clean, production-ready MongoDB interface for animal shelter data."""
    
    def __init__(self, username: str = "aacuser", password: str = "SNHU1234"):
        """
        Establishes MongoDB connection with simplified authentication.
        
        Args:
            username: Database username (default 'aacuser')
            password: Database password (default 'SNHU1234')
        """
        # Configuration
        self.CLUSTER = "cluster0.uf2bgmu.mongodb.net"
        self.DATABASE = "AAC"
        self.COLLECTION = "animals"
        
        # Initialize connection
        self.client = MongoClient(
            f"mongodb+srv://{urllib.parse.quote_plus(username)}:"
            f"{urllib.parse.quote_plus(password)}@"
            f"{self.CLUSTER}/{self.DATABASE}"
            "?retryWrites=true&w=majority",
            serverSelectionTimeoutMS=5000
        )
        self.db = self.client[self.DATABASE]
        self.collection = self.db[self.COLLECTION]

    def read(self, query: Dict = None, 
             projection: Dict = None,
             limit: int = 0) -> List[Dict]:
        """
        Retrieves documents with optional filtering and field selection.
        
        Args:
            query: MongoDB query document
            projection: Fields to include/exclude
            limit: Maximum documents to return (0 for no limit)
            
        Returns:
            List of matching documents (empty list on error)
        """
        try:
            cursor = self.collection.find(query or {}, projection or {})
            if limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError:
            return []

    def __enter__(self):
        """Context manager entry point."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Ensures proper connection cleanup."""
        self.client.close()

    def close(self) -> None:
        """Explicit connection closure."""
        self.client.close()